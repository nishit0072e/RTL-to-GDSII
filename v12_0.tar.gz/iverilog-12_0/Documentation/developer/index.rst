
Icarus Verilog Developer Support
================================

This section contains documents to help support developers who contribute to
Icarus Verilog.

.. toctree::
   :maxdepth: 1

   getting_started
   version_stamps

