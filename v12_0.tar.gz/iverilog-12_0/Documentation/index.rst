.. Icarus Verilog documentation master file, created by
   sphinx-quickstart on Sun Apr 10 16:28:38 2022.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Icarus Verilog
==============

Welcome to the documentation for Icarus Verilog.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   usage/index
   targets/index
   developer/index


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
