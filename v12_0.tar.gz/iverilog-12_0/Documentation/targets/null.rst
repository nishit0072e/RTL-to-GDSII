
The null Code Generator (-tnull)
================================

The null target generates no code. Invoking this code generator causes no code
generation to happen.

