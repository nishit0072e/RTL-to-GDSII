
The vvp Code Generator (-tvvp)
==============================

The vvp target generates code for the "vvp" run time. This is the most
commonly used target for Icarus Verilog, as it is the main simulation engine.
